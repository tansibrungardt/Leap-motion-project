let stateCapitals = {
    AR: "Little Rock",
    CO: "Denver",
    NM: "Sante Fe"
 };